import { Observable } from '@nativescript/core';
import { Recipe } from '../models/recipe.model';
import { RecipeService } from '../services/recipe.service';
import { filterRecipes, RecipeFilters } from '../utils/recipe-filters.util';

export class RecipesViewModel extends Observable {
    private _recipes: Recipe[] = [];
    private _filters: RecipeFilters = {
        isVegan: false,
        isQuick: false,
        isLowBudget: false
    };
    private recipeService: RecipeService;

    constructor() {
        super();
        this.recipeService = new RecipeService();
        this.loadRecipes();
    }

    get recipes(): Recipe[] {
        return filterRecipes(this._recipes, this._filters);
    }

    async loadRecipes() {
        this._recipes = await this.recipeService.getRecipes();
        this.notifyPropertyChange('recipes', this.recipes);
    }

    toggleVegan() {
        this._filters.isVegan = !this._filters.isVegan;
        this.notifyPropertyChange('recipes', this.recipes);
    }

    toggleQuick() {
        this._filters.isQuick = !this._filters.isQuick;
        this.notifyPropertyChange('recipes', this.recipes);
    }

    toggleLowBudget() {
        this._filters.isLowBudget = !this._filters.isLowBudget;
        this.notifyPropertyChange('recipes', this.recipes);
    }
}