import { GridLayout } from '@nativescript/core';

export class RecipeCard extends GridLayout {
    constructor() {
        super();
    }
}