import { GridLayout } from '@nativescript/core';

export class RecipeFilters extends GridLayout {
    constructor() {
        super();
    }
}