export interface ShoppingItem {
    id: string;
    name: string;
    completed: boolean;
}